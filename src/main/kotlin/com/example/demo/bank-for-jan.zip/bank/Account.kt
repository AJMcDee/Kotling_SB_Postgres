package com.example.demo.bank

data class UpdateRequest (val iban: String, val token: String, val amount: Double, val operation: String )
data class AccessRequest (val iban: String, val token: String)
data class LoginAttempt (val iban: String, val password: String)

data class Account(var name: String = "", val iban: String, var balance: Double = 0.00, val password: String = "password123", var token: String = "") {

    fun updateBalance(amount: Double, operation: String) {
        if (operation == "withdraw") {
            if (amount > this.balance) throw Error("Withdrawal amount too high")
            else this.balance -= amount;
        } else if (operation == "deposit") {
            this.balance += amount;
        }
    }

    override fun toString(): String {
        return "Account for $name, IBAN $iban, now has balance $$balance."

    }
}