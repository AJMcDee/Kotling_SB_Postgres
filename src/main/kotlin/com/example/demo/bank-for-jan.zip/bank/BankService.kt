package com.example.demo.bank

import org.springframework.stereotype.Service
import kotlin.math.floor

@Service
class BankService {

    val myNewAcc1: Account = Account("Anna", "RKWLW", 450.24)
    val myNewAcc2: Account = Account("Bob", "RKWLWqwe", 10.11)
    var accounts: MutableList<Account> = mutableListOf(myNewAcc1, myNewAcc2)

    fun getNewToken() : String {
        var token = ""
        val randomCollection = "r29afKw02Pmlgp9201Odfqzxru"
        for (i in 1..25) {
            token += randomCollection[floor(Math.random()*25).toInt()]
        }
        return token
    }

    fun authenticate(loginAttempt : LoginAttempt): String {
        val currentAccount = accounts.firstOrNull { it.iban == loginAttempt.iban && it.password == loginAttempt.password }
        if (currentAccount == null) {
            throw Error("No such account exists")
        } else {
            val token = getNewToken()
            currentAccount.token = token;
            return token
        }
    }

    fun getAllAccounts(): List<Account> {
        return accounts
    }

    fun getAccountByIBAN(iban: String): Account {
        for (account in accounts) {
            if (account.iban == iban) return account
        }
        throw Error("No such account exists");
    }

    fun addAccount(newAccount: Account): MutableList<Account> {
        accounts.add(newAccount)
        return accounts
    }

    fun verifyAccountAccess(accessRequest: AccessRequest) : Account {
        return accounts.first{ it.iban == accessRequest.iban && it.token == accessRequest.token }
    }

    fun deleteAccount(accessRequest: AccessRequest) : MutableList<Account> {
            accounts.remove(verifyAccountAccess(accessRequest))
            return accounts;
    }

    fun updateBalance(updateRequest: UpdateRequest) : Account {
        val accessRequest = AccessRequest(updateRequest.iban, updateRequest.token)
        var currentAccount = verifyAccountAccess(accessRequest)
        currentAccount.updateBalance(updateRequest.amount,updateRequest.operation)
        return currentAccount
    }
}
