package com.example.demo.bank

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.web.bind.annotation.*
import org.springframework.web.bind.annotation.RequestBody

import org.springframework.web.bind.annotation.PostMapping
import java.lang.Exception


@SpringBootApplication
@RestController("/")



class BankController (private val bankService: BankService){


    @GetMapping("/accounts")
    fun sendAccounts(): List<Account> {
        return bankService.getAllAccounts();
    }

    @GetMapping("/account/{iban}")
    fun getAccount(@PathVariable iban: String): Account {
return bankService.getAccountByIBAN(iban);
    }

    @PostMapping(path = ["/accounts"], consumes = ["application/json"], produces = ["application/json"])
    fun addMember(@RequestBody newAccount : Account): MutableList<Account> {
return bankService.addAccount(newAccount);
    }

    @DeleteMapping("/account", consumes = ["application/json"], produces = ["application/json"])
    fun deleteAccount(@RequestBody accessRequest: AccessRequest): MutableList<Account> {
        return bankService.deleteAccount(accessRequest)
    }

    @PostMapping(path = ["/account"], consumes = ["application/json"], produces=["application/json"])
    fun updateBalance(@RequestBody updateRequest: UpdateRequest): Account {
        return bankService.updateBalance(updateRequest)

    }

    @PostMapping(path = ["/authenticate"], consumes = ["application/json"], produces=["application/json"])
    fun authenticate(@RequestBody loginAttempt: LoginAttempt): String {
        return bankService.authenticate(loginAttempt)
    }


}